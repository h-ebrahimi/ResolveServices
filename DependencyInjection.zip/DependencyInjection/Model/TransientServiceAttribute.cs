﻿using System;

namespace SadadPsp.SharedKernel.DependencyInjection
{
    /// <summary>
    /// Class TransientAttribute. This class cannot be inherited.
    /// Implements the <see cref="System.Attribute" />
    /// </summary>
    /// <seealso cref="System.Attribute" />
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Interface, AllowMultiple = false)]
    public sealed class TransientServiceAttribute : Attribute
    {
    }
}

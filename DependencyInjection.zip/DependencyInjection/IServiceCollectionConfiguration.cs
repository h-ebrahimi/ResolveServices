﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace SadadPsp.SharedKernel.DependencyInjection
{
    public interface IServiceCollectionConfiguration
    {
        void Configure(IServiceCollection services, IConfiguration configuration);
    }
}

﻿using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;

namespace SadadPsp.SharedKernel.DependencyInjection
{
    public static class ServiceCollectionConfigurationHandler
    {
        public static void RegisterServices(IServiceCollection serviceCollection, IConfiguration configuration)
        {
            var serviceInformations = configuration.GetSection("services")
                .Get<List<ServiceConfigurationInformation>>();

            var currentPath = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);

            var imapperServices = serviceCollection.Any(t => t.ServiceType == typeof(IMapper));

            foreach (var service in serviceInformations)
            {
                var targetType = Type.GetType($"{service.Configuration}, {service.AssemblyName}");
                if (targetType == null)
                {
                    var assembly = System.Runtime.Loader.AssemblyLoadContext.Default.LoadFromAssemblyPath($"{currentPath}\\{service.AssemblyName}.dll");
                    AppDomain.CurrentDomain.Load(assembly.GetName());
                    targetType = assembly.GetType(service.Configuration);
                }

                var myInstance = Activator.CreateInstance(targetType);
                var serviceCollectionConfigurationInstance = myInstance as IServiceCollectionConfiguration;
                serviceCollectionConfigurationInstance.Configure(serviceCollection, configuration);

                var imapperService = serviceCollection.Any(t => t.ServiceType == typeof(IMapper));
            }
        }

        public static void RegisterMappingProfiler(IServiceCollection services, IConfiguration configuration)
        {
            //var serviceInformations = configuration.GetSection("services")
            //    .Get<List<ServiceConfigurationInformation>>();

            //var currentPath = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
            //var assemblyList = new List<Assembly>();

            //foreach (var service in serviceInformations)
            //{
            //    var targetType = Type.GetType($"{service.Configuration}, {service.AssemblyName}");
            //    var assembly = targetType?.Assembly;

            //    if (targetType == null)
            //        assembly = System.Runtime.Loader.AssemblyLoadContext
            //            .Default.LoadFromAssemblyPath($"{currentPath}\\{service.AssemblyName}.dll");

            //    assemblyList.Add(assembly);
            //}
            var assemblyList = AppDomain.CurrentDomain.GetAssemblies().Where(t => !t.FullName.Contains("Microsoft") && !t.FullName.Contains("System")).ToArray();
            services.AddAutoMapper(assemblyList);
        }

        /// <summary>
        /// Adds the services(interface/class) with attribute.
        /// </summary>
        /// <param name="serviceCollection">The service collection.</param>
        public static void AddServicesWithAttribute(this IServiceCollection serviceCollection)
        {
            var currentPath = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
            string searchPattern = $"*.dll";
            var assemblyPaths = Directory.GetFiles(currentPath, searchPattern)?.ToList() ?? null;

            if (assemblyPaths == null || !assemblyPaths.Any())
                return;

            var loadedAssemblies = new List<Assembly>();
            foreach (string path in assemblyPaths)
            {
                try
                {
                    // Load Assembly
                    loadedAssemblies.Add(Assembly.LoadFile(path));
                }
                catch (Exception)
                {
                    continue;
                }
            }

            var implementationToBeRegistered = loadedAssemblies.SelectMany(assembly => assembly.GetTypes()).Where(exp => !exp.IsGenericType && exp.IsClass && (exp.IsDefined(typeof(SingletonServiceAttribute)) || exp.IsDefined(typeof(ScopedServiceAttribute)) || exp.IsDefined(typeof(TransientServiceAttribute)))).ToList();

            if (implementationToBeRegistered == null || !implementationToBeRegistered.Any())
                return;

            IEnumerable<Type> allInterfaces;
            Attribute customAttribute;
            ServiceLifetime lifeTime;
            bool isAlreadyRegistered;
            foreach (var implementation in implementationToBeRegistered)
            {
                // Get Attribute of type 
                customAttribute = implementation.GetCustomAttributes()?.Where(exp => exp is SingletonServiceAttribute || exp is ScopedServiceAttribute || exp is TransientServiceAttribute).FirstOrDefault() ?? null;

                if (customAttribute == null)
                    continue;

                // Detect type of Attribute
                lifeTime = ServiceLifetime.Scoped;
                if (customAttribute is SingletonServiceAttribute)
                    lifeTime = ServiceLifetime.Singleton;
                else if (customAttribute is TransientServiceAttribute)
                    lifeTime = ServiceLifetime.Transient;

                // Get interfaces of type
                allInterfaces = implementation.GetInterfaces()?.Except(implementation.BaseType?.GetInterfaces());
                allInterfaces = allInterfaces?.Except(allInterfaces.SelectMany(exp => exp.GetInterfaces())).ToList();
                isAlreadyRegistered = false;
                if (allInterfaces == null || !allInterfaces.Any())
                {
                    isAlreadyRegistered = serviceCollection.Any(s => s.ImplementationType == implementation);
                    if (isAlreadyRegistered)
                        continue;

                    // Register service
                    serviceCollection.Add(new ServiceDescriptor(implementation, implementation, lifeTime));
                }
                else
                {
                    foreach (var interfaceService in allInterfaces)
                    {
                        isAlreadyRegistered = serviceCollection.Any(s => s.ServiceType == interfaceService && s.ImplementationType == implementation);
                        if (isAlreadyRegistered)
                            continue;

                        // Register service
                        serviceCollection.Add(new ServiceDescriptor(interfaceService, implementation, lifeTime));
                    }
                }
            }
        }
    }
}
